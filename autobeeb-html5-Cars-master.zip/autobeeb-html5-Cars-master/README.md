HTML5 Genetic Cars
==================

A genetic algorithm car evolver in HTML5 canvas.

This is inspired by BoxCar2D, and uses the same physics engine, Box2D, but it's written from scratch.

This is the code as published on http://rednuht.org/genetic_cars_2/

The current module-based format required npm and browserify.

Build with:

npm run-script build
